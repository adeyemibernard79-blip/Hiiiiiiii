package com.nexora.play.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexora.play.AppViewModel

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Library("Library", Icons.AutoMirrored.Filled.List),
    Cloud("Cloud", Icons.Filled.PlayArrow),
    Settings("Settings", Icons.Filled.Settings),
}

@Composable
fun NexoraApp(vm: AppViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1030), Color(0xFF070A14))))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xE60F1424)) {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) },
                        )
                    }
                }
            },
        ) { pad ->
            Crossfade(tab, Modifier.padding(pad).statusBarsPadding(), label = "tab") { t ->
                when (t) {
                    Tab.Home -> HomeScreen(vm) { tab = it }
                    Tab.Library -> LibraryScreen(vm)
                    Tab.Cloud -> CloudScreen()
                    Tab.Settings -> SettingsScreen(vm)
                }
            }
        }
    }
}
