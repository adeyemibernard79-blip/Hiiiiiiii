package com.nexora.play

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.play.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings: StateFlow<Settings> = app.dataStore.data.map { it.toSettings() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    private val _games = MutableStateFlow<List<Game>>(emptyList())
    val games = _games.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    val scanning = _scanning.asStateFlow()

    init {
        viewModelScope.launch {
            settings.map { it.romUri }.distinctUntilChanged().collect { rescan() }
        }
    }

    fun rescan() {
        val uri = settings.value.romUri ?: run { _games.value = emptyList(); return }
        viewModelScope.launch {
            _scanning.value = true
            _games.value = withContext(Dispatchers.IO) {
                runCatching { RomScanner.scan(getApplication(), Uri.parse(uri)) }.getOrDefault(emptyList())
            }
            _scanning.value = false
        }
    }

    fun setRomFolder(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        save { it[Keys.ROM_URI] = uri.toString() }
    }

    fun setQuality(q: String) = save { it[Keys.QUALITY] = q }
    fun setFps(f: Int) = save { it[Keys.FPS] = f }
    fun setPadOpacity(v: Float) = save { it[Keys.PAD_OPACITY] = v }

    private fun save(block: (MutablePreferences) -> Unit) {
        viewModelScope.launch { getApplication<Application>().dataStore.edit { block(it) } }
    }
}
