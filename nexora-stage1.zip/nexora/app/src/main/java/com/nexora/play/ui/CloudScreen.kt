package com.nexora.play.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CloudScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Cloud", style = MaterialTheme.typography.headlineMedium)
        Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("No streaming server connected", style = MaterialTheme.typography.titleMedium)
            Text("Cloud play needs a computer or GPU server that actually runs the games. " +
                "When you have one, you will add its address here and pair with it. " +
                "Until then this section shows no games and no fake availability.")
        }
    }
}
