# Nexora (stage 2: on-phone emulators)
Upload this zip to your GitHub repo as `nexora-stage1.zip` (replace the old one). The existing
build workflow then builds the APK. The emulator cores are downloaded automatically during the build.
Bring your own legally obtained games (PSP .iso/.cso/.pbp, PS1 .cue+.bin/.chd, DS .nds).
